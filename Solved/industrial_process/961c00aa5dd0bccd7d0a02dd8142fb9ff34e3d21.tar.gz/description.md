In company XXX, we have a big expertise in laser cutting and we are well informed about cybersecurity. We have setup a small honeypot to simulate the cut of some pieces. In our fake process, we have manufactured 25 pieces of 1 meter by 1 meter.
We have found this really weird file thanks to a super effective detection tool. There was also a weird string : `893c539a84e6c96acf5f2ceea2ad9ef7be895580`

This flag follow the following format : INSA([A-Z]*). Please submit it as INSA{$1}, for example if you find INSAAZERTY, submit INSA{AZERTY}.
[Weird File](https://static.ctf.insecurity-insa.fr/961c00aa5dd0bccd7d0a02dd8142fb9ff34e3d21.tar.gz)
