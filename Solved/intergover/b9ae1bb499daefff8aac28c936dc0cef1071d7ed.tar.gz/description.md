I hope you know how integers are stored.

`ssh -i <your_keyfile> -p 2223 user@intergover.ctf.insecurity-insa.fr`
To find your keyfile, look into your profile on this website.

[Binary](https://static.ctf.insecurity-insa.fr/b9ae1bb499daefff8aac28c936dc0cef1071d7ed.tar.gz)

[https://www.youtube.com/watch?v=_BgblvF90UE](https://www.youtube.com/watch?v=_BgblvF90UE)